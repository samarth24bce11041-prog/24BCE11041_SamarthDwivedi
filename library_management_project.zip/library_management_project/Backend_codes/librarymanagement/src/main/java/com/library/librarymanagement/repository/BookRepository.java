package com.library.librarymanagement.repository;

import com.library.librarymanagement.model.Book;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface BookRepository extends MongoRepository<Book, String> {
}
