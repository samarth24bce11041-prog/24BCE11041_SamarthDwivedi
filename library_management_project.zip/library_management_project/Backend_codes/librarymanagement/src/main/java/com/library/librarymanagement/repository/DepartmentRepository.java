package com.library.librarymanagement.repository;

import com.library.librarymanagement.model.Department;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DepartmentRepository extends MongoRepository<Department, String> {
}