package com.library.librarymanagement.controller;

import com.library.librarymanagement.model.Department;
import com.library.librarymanagement.repository.DepartmentRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/departments")
public class DepartmentController {

    private final DepartmentRepository departmentRepository;

    // Constructor Injection
    public DepartmentController(DepartmentRepository departmentRepository) {
        this.departmentRepository = departmentRepository;
    }

    // 1. POST /departments (Create)
    @PostMapping
    public Department createDepartment(@RequestBody Department department) {
        return departmentRepository.save(department);
    }

    // 2. GET /departments (Get All)
    @GetMapping
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    // 3. PUT /departments/{id} (Update)
    @PutMapping("/{id}")
    public Department updateDepartment(@PathVariable String id, @RequestBody Department departmentDetails) {
        Department department = departmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Department not found with id: " + id));
        
        department.setDepartmentName(departmentDetails.getDepartmentName());
        return departmentRepository.save(department);
    }

    // 4. DELETE /departments/{id} (Delete)
    @DeleteMapping("/{id}")
    public String deleteDepartment(@PathVariable String id) {
        departmentRepository.deleteById(id);
        return "Department deleted successfully with id: " + id;
    }
}