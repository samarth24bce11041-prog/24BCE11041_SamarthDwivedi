package com.library.librarymanagement.controller;

import com.library.librarymanagement.model.IssueRecord;
import com.library.librarymanagement.repository.IssueRecordRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/issues")
public class IssueRecordController {

    private final IssueRecordRepository issueRecordRepository;

    public IssueRecordController(IssueRecordRepository issueRecordRepository) {
        this.issueRecordRepository = issueRecordRepository;
    }

    // 1. Issue a Book with Availability Check
    @PostMapping
    public ResponseEntity<?> issueBook(@RequestBody IssueRecord record) {
        // Check karo kya book pehle se issued hai?
        Optional<IssueRecord> existingIssue = issueRecordRepository.findByBookIdAndReturnDateIsNull(record.getBookId());
        
        if (existingIssue.isPresent()) {
            return ResponseEntity.badRequest().body("Error: This book is already issued to someone else and not returned yet!");
        }

        record.setIssueDate(new Date()); 
        record.setReturnDate(null);
        record.setFineAmount(0.0);
        
        IssueRecord savedRecord = issueRecordRepository.save(record);
        return ResponseEntity.ok(savedRecord);
    }

    // 2. Get All Issue History
    @GetMapping
    public List<IssueRecord> getAllRecords() {
        return issueRecordRepository.findAll();
    }

    // 3. Return a Book with Automatic Fine Calculation (14 days rule)
    @PutMapping("/return/{id}")
    public ResponseEntity<?> returnBook(@PathVariable String id) {
        IssueRecord record = issueRecordRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Transaction record not found with id: " + id));
        
        if (record.getReturnDate() != null) {
            return ResponseEntity.badRequest().body("Error: This book has already been returned!");
        }

        Date today = new Date();
        record.setReturnDate(today);

        // Fine Logic: Check difference between today and issueDate
        long diffInMillies = Math.abs(today.getTime() - record.getIssueDate().getTime());
        long diffInDays = diffInMillies / (1000 * 60 * 60 * 24);

        double fine = 0.0;
        if (diffInDays > 14) {
            long extraDays = diffInDays - 14;
            fine = extraDays * 5.0; // ₹5 per day fine
        }
        
        record.setFineAmount(fine);
        IssueRecord updatedRecord = issueRecordRepository.save(record);
        return ResponseEntity.ok(updatedRecord);
    }
}