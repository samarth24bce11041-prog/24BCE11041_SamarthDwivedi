package com.library.librarymanagement.repository;

import com.library.librarymanagement.model.IssueRecord;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.Optional;

public interface IssueRecordRepository extends MongoRepository<IssueRecord, String> {
    // Yeh check karega ki kya yeh book pehle se kisi ne li hui hai aur return nahi ki
    Optional<IssueRecord> findByBookIdAndReturnDateIsNull(String bookId);
}
