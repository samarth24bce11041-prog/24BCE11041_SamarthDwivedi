package com.library.librarymanagement.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.Date;

@Document(collection = "issue_records")
public class IssueRecord {
    
    @Id
    private String issueId;
    private String bookId;       // Kaun si book issue hui
    private String userId;       // Kisne issue karwayi (Student ID ya Staff ID)
    private String userType;     // "STUDENT" ya "STAFF"
    private Date issueDate;      // Kab issue hui
    private Date returnDate;     // Kab return hui (shuru mein null rahega)
    private double fineAmount; // Naya field fine ke liye
    
    // Default Constructor
    public IssueRecord() {
        this.issueDate = new Date(); // Automatically aaj ki date set ho jayegi
    }

    // Parameterized Constructor
    public IssueRecord(String bookId, String userId, String userType) {
        this.bookId = bookId;
        this.userId = userId;
        this.userType = userType;
        this.issueDate = new Date();
    }

    // Getters and Setters
    public String getIssueId() {
        return issueId;
    }

    public void setIssueId(String issueId) {
        this.issueId = issueId;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public Date getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }    
    public double getFineAmount() {
        return fineAmount;
    }

    public void setFineAmount(double fineAmount) {
        this.fineAmount = fineAmount;
    }   
 }
