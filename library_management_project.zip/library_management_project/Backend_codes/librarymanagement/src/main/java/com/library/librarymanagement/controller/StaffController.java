package com.library.librarymanagement.controller;

import com.library.librarymanagement.model.Staff;
import com.library.librarymanagement.repository.StaffRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/staff")
public class StaffController {

    private final StaffRepository staffRepository;

    public StaffController(StaffRepository staffRepository) {
        this.staffRepository = staffRepository;
    }

    // 1. POST /staff (Create)
    @PostMapping
    public Staff createStaff(@RequestBody Staff staff) {
        return staffRepository.save(staff);
    }

    // 2. GET /staff (Get All)
    @GetMapping
    public List<Staff> getAllStaff() {
        return staffRepository.findAll();
    }

    // 3. PUT /staff/{id} (Update)
    @PutMapping("/{id}")
    public Staff updateStaff(@PathVariable String id, @RequestBody Staff staffDetails) {
        Staff staff = staffRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Staff member not found with id: " + id));
        
        staff.setStaffName(staffDetails.getStaffName());
        staff.setDesignation(staffDetails.getDesignation());
        staff.setDepartmentId(staffDetails.getDepartmentId());
        
        return staffRepository.save(staff);
    }

    // 4. DELETE /staff/{id} (Delete)
    @DeleteMapping("/{id}")
    public String deleteStaff(@PathVariable String id) {
        staffRepository.deleteById(id);
        return "Staff member deleted successfully with id: " + id;
    }
}