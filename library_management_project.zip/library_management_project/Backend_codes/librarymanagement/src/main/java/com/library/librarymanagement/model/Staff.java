package com.library.librarymanagement.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "staff")
public class Staff {
    
    @Id
    private String staffId;
    private String staffName;
    private String designation; // Jaise: Professor, Assistant, Librarian
    private String departmentId; // Department se link karne ke liye

    // Default Constructor
    public Staff() {}

    // Parameterized Constructor
    public Staff(String staffName, String designation, String departmentId) {
        this.staffName = staffName;
        this.designation = designation;
        this.departmentId = departmentId;
    }

    // Getters and Setters
    public String getStaffId() {
        return staffId;
    }

    public void setStaffId(String staffId) {
        this.staffId = staffId;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }
}